class AiReportSectionsController < ApplicationController
  skip_after_action :verify_authorized
  skip_after_action :verify_policy_scoped

  def update
    @report = AiPortfolioReport.find(params[:ai_portfolio_report_id])
    @section = @report.ai_report_sections.find(params[:id])

    if @section.update(section_params)
      redirect_to ai_portfolio_report_path(@report, section_id: @section.id), notice: 'Section saved.'
    else
      redirect_to ai_portfolio_report_path(@report, section_id: @section.id), alert: 'Failed to save section.'
    end
  end

  def add_content
    @report = AiPortfolioReport.find(params[:ai_portfolio_report_id])
    @section = @report.ai_report_sections.find(params[:id])
    content_to_add = params[:content]

    # Add attribution
    attributed_content = "#{content_to_add}\n\n-- Added from AI at #{Time.current.strftime('%H:%M')} --\n\n"

    # Append to section content
    if @section.content.body.present?
      @section.content.body = @section.content.body.to_s + attributed_content
    else
      @section.content = attributed_content
    end

    @section.save!

    render json: { success: true, content: @section.content.body.to_s }
  end

  private

  def section_params
    params.require(:ai_report_section).permit(:content)
  end
end
