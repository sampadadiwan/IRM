import { Controller } from "@hotwired/stimulus"

export default class ServerDatatableController extends Controller {

  static values = {
    lazyLoadData: String, // Do we want to eager or lazy load (for tabs)
    tableName: String, // Which table id are we targeting
    fieldList: String, // Which fields are we targeting
  }

  connect() {
    console.log(`Datatable setup for ${this.tableNameValue}`);
    console.log(`lazyLoadDataValue = ${this.lazyLoadDataValue}`);
    console.log(`fieldListValue = ${this.fieldListValue}`);
        
    if(this.lazyLoadDataValue == "false") {
      this.loadData();
    }    

    this.finalizeTable();
  }

  // This is the main function that builds the datatable
  // In server_datatable_controller.js, we call this inside the loadData function
  // To only create the table when we want to load the data
  buildTable(table_id) {
    let table = null;

    if ( $.fn.dataTable.isDataTable( $(table_id) ) ) {
    }
    else {
    table = $(table_id).DataTable({
        "processing": true,
        "serverSide": true,
        responsive: {
          details: this.showDetailsResponsive(),
        },        
        stateSave: true,
        search: {
          // return: true,
        },

        searching: this.searchEnabled(),
        
        "ajax": {
          "url": $(table_id).data('source')
        },
        // "pagingType": "full_numbers",
        language: {
          search: '',
          searchPlaceholder: "Search...",
          paginate: {
          }          
        },
        "columns": this.columns(),
        "initComplete": function() 
        {
          console.log(`initComplete ${table_id}`);
         $(`${table_id}_filter input`)
          .unbind() // Unbind previous default bindings
          .bind("input", function(e) { // Bind our desired behavior
              // If the length is 3 or more characters, or the user pressed ENTER, search
              if(this.value.length >= 3 || e.keyCode == 13) {
                  // Call the API search function
                  table.search(this.value).draw();
              }
              // Ensure we clear the search if they backspace far enough
              if(this.value == "") {
                table.search("").draw();
              }
              return;
          });
          
        }
      });
    }
    

    // Ensure DataTable is destroyed, else it gets duplicated
    $(document).on('turbo:before-cache', function() {    
      if ( $.fn.dataTable.isDataTable( table ) ) { 
        table.destroy();
      }      
    });

    return table;
  }

  showDetailsResponsive() {
    return true;
  }

  searchEnabled() {
    return true;
  }

  columns() {    
    console.log("server_datatable_controller columns called");
    let cols = this.customColumns();
    console.log("cols", cols);  
    return cols;
  }

  customColumns() {
    console.log("server_datatable_controller customColumns called");
    let fields = this.fieldListValue.split(",");
    if (this.fieldListValue == "") {
      return [];
    } else  {
      return fields.map(function(item) {
        return {"data": item};
      });
    }    
  }

  loadData() {        
    let table = this.buildTable(this.tableNameValue);
    let dataSource = $(this.tableNameValue).data('source')
    console.log(`loadData called table = ${this.tableNameValue} dataSource= ${dataSource}`);
    // table.ajax.url( dataSource ).load();
  }

  replaceQueryParam(param, newval, path) {
    var regex = new RegExp("([?;&])" + param + "[^&;]*[;&]?");
    var query = path.replace(regex, "$1").replace(/&$/, '');

    return (query.length > 2 ? query + "&" : "?") + (newval ? param + "=" + newval : '');
  }

  finalizeTable() {
    console.log("server_datatable_controller finalizeTable called");
  }
};
